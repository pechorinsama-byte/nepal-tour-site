export default function Page() {
  return (
    <main style={{ padding: '40px' }}>
      <h1>Nepal Adventure Tour</h1>
      <p>Страница тура будет оформлена позже — структура уже готова.</p>
    </main>
  );
}
